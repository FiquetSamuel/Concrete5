	<div id="footer"></div>
	<?php Loader::element('footer_required');?>
  </body>
</html>